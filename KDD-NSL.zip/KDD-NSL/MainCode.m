%% 
clc; clear; close all;

%% Reading the test data
% Input file name
input_filename = 'KDDTest+.txt';
% Open the txt file
fid = fopen(input_filename);
% Read the txt file's content
file = textscan(fid,'%s','delimiter','\n');
% The size of txt file
n = length(file);
content = char(file{1,1});
[d1,d2] = size(content);
% Removing space between samples
for i= 1:d1
Test{i} = textscan(content(i,:),'%s','delimiter',',');  
end 

%% Reading the train data
input_filename = 'KDDTrain+.txt';
fid = fopen(input_filename);
file = textscan(fid,'%s','delimiter','\n');
n = length(file);
content = char(file{1,1});
[d1,d2] = size(content);
for i = 1:d1
Train{i} = textscan(content(i,:),'%s','delimiter',',');  
end
%% Converting nominal data to numeric
F2 = {'udp','tcp','icmp'};                                   % 2nd Feature
F2_num = 1:length(F2);

F3 = {'aol'; 'http_443'; 'http_8001'; 'http_2784';...        % 3rd Feature
           'domain_u'; 'ftp_data'; 'auth'; 'bgp'; 'courier';...
           'tftp_u'; 'uucp_path'; 'csnet_ns'; 'ctf';...
           'daytime';'time'; 'discard'; 'domain'; 'echo';...
           'eco_i'; 'ecr_i'; 'efs'; 'exec'; 'finger'; 'gopher';...
           'harvest'; 'hostnames'; 'http'; 'imap4'; 'IRC';...
           'iso_tsap'; 'klogin'; 'kshell'; 'ldap'; 'link';...
           'login'; 'smtp'; 'mtp'; 'name';...
           'netbios_dgm'; 'netbios_ns'; 'netbios_ssn'; 'netstat';...
           'nnsp'; 'nntp'; 'ntp_u'; 'other'; 'pm_dump'; 'pop_2';...
           'pop_3'; 'printer'; 'private'; 'red_i'; 'remote_job'; ...
           'rje'; 'shell'; 'sql_net'; 'ssh'; 'sunrpc';...
           'supdup'; 'systat'; 'telnet'; 'tim_i';...
           'urh_i'; 'urp_i'; 'uucp';'ftp'; 'vmnet';...
           'whois'; 'X11'; 'Z39_50'};
F3_num = 1:length(F3);

F4 = {'OTH';'REJ';'RSTO';'RSTOS0';'RSTR';'RSTRH';'S0';...  % 4th Feature 
    'S1';'S2';'S3';'SF';'SH';'SHR'};
F4_num = 1:length(F4);
%% Test Numeric Input
Test_numeric_in = {};
tic;
for i = 1:length(Test)
Temp = Test{i}{1};
Test_numeric_in{i,1} =  str2num(Temp{1});
Test_numeric_in{i,2} = (F2_num(strcmp(Temp{2},F2)));
Test_numeric_in{i,3} = (F3_num(strcmp(Temp{3},F3)));
Test_numeric_in{i,4} = (F4_num(strcmp(Temp{4},F4)));
for k = 5:41
Test_numeric_in{i,k} = str2num(Temp{k});
end 
end


%% Test Numeric Output
DoS = {'back','land','neptune','pod','smurf','teardrop',...
    'apache2','udpstorm','processtable','worm'};
Probe = {'satan','ipsweep','nmap','portsweep','mscan','saint'};
R2L = {'guess_passwd', 'ftp_write','imap','phf',...
'multihop', 'warezmaster', 'warezclient', 'spy',...
'xlock', 'xsnoop', 'snmpguess', 'snmpgetattack',...
'httptunnel', 'sendmail', 'named'};
U2R = {'buffer_overflow', 'loadmodule', 'rootkit', 'perl',...
'sqlattack', 'xterm', 'ps'};
Normal = {'normal'};
Test_numeric_out = [];

for i = 1:length(Test)
  Temp = Test{i}{1};  
if sum(strcmp(Temp{42},DoS)~=0)
    Flag1 = 1;    %% DoS attack
elseif sum(strcmp(Temp{42},Probe)~=0)
    Flag1 = 2;    %% Probe attack
elseif sum(strcmp(Temp{42},R2L)~=0)
    Flag1 = 3;    %% R2L attack
elseif sum(strcmp(Temp{42},U2R)~=0)
    Flag1 = 4;    %% U2R attack
    elseif sum(strcmp(Temp{42},Normal)~=0)
    Flag1 = 0;    %% Normal
end
Test_numeric_out(i) = Flag1;
end 
Test_numeric_out = Test_numeric_out';

%% Train Numeric Input
Train_numeric_in = {};
for i = 1:length(Train)
Temp = Train{i}{1};
Train_numeric_in{i,1} =  str2num(Temp{1});
Train_numeric_in{i,2} = (F2_num(strcmp(Temp{2},F2)));
Train_numeric_in{i,3} = (F3_num(strcmp(Temp{3},F3)));
Train_numeric_in{i,4} = (F4_num(strcmp(Temp{4},F4)));
for k = 5:41
Train_numeric_in{i,k} = str2num(Temp{k});
end 
end
%% Test Numeric Output
Train_numeric_out = [];
Normal = {'normal'};
for i = 1:length(Train)
  Temp = Train{i}{1};  
if sum(strcmp(Temp{42},DoS)~=0)
    Flag1 = 1;    %% DoS attack
elseif sum(strcmp(Temp{42},Probe)~=0)
    Flag1 = 2;    %% Probe attack
elseif sum(strcmp(Temp{42},R2L)~=0)
    Flag1 = 3;    %% R2L attack
elseif sum(strcmp(Temp{42},U2R)~=0)
    Flag1 = 4;    %% U2R attack
elseif sum(strcmp(Temp{42},Normal)~=0)
Flag1 = 0;    %% Normal
end
Train_numeric_out(i) = Flag1;
end 
Train_numeric_out = Train_numeric_out';

%% Converting Cell to Matrix
Train_numeric_in1 = cell2mat(Train_numeric_in);
Test_numeric_in(cellfun('isempty',Test_numeric_in)) = {0};
Test_numeric_in1 = cell2mat(Test_numeric_in); 
save('My_Data')



